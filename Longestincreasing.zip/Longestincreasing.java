package practiceproject;

import java.util.*;

public class Longestincreasing {

	private final int[] input;

	public Longestincreasing(int[] input) {
		this.input = input;
	}

	public List<Integer> findLongestincreasingseq() {
		int n = input.length;
		int[] listlength = new int[n];
		int[] beforeIndex = new int[n];

		for (int i = 0; i < n; i++) {
			listlength[i] = 1;
			beforeIndex[i] = -1;
		}

		int maxlength = 1;
		int previousIndex = 0;

		for (int i = 1; i < n; i++) {
			for (int j = 0; j < i; j++) {
				if (input[i] > input[j] && listlength[i] < listlength[j] + 1) {
					listlength[i] = listlength[j] + 1;
					beforeIndex[i] = j;
				}
			}
			if (listlength[i] > maxlength) {
				maxlength = listlength[i];
				previousIndex = i;
			}
		}

		List<Integer> longestsubsequence = new ArrayList<>();
		while (previousIndex >= 0) {
			longestsubsequence.add(input[previousIndex]);
			previousIndex = beforeIndex[previousIndex];
		}

		List<Integer> reversedsubsequence = new ArrayList<>();
		for (int i = longestsubsequence.size() - 1; i >= 0; i--) {
			reversedsubsequence.add(longestsubsequence.get(i));
		}

		return reversedsubsequence;
	}

	public static void main(String[] args) {
		int[] numbers = {11,44,22,99,56,23,73,90,23,99,66};

		// displaying the given array within [ ]
		StringBuilder arrayString = new StringBuilder("[");
		for (int i = 0; i < numbers.length; i++) {
			arrayString.append(numbers[i]);
			if (i < numbers.length - 1) {
				arrayString.append(", ");
			}
		}
		arrayString.append("]");
		System.out.println("Given Input Array: " + arrayString.toString());

		Longestincreasing list = new Longestincreasing(numbers);
		List<Integer> longestincreasingsubsequence = list.findLongestincreasingseq();
		
		// displaying the output array within [ ]
		StringBuilder listString = new StringBuilder("[");
		for (int i = 0; i < longestincreasingsubsequence.size(); i++) {
			listString.append(longestincreasingsubsequence.get(i));
			if (i < longestincreasingsubsequence.size() - 1) {
				listString.append(", ");
			}
		}
		listString.append("]");
		System.out.println("\nLongest increasing subsequence among the numbers in the list: " + listString.toString());
	}
}
