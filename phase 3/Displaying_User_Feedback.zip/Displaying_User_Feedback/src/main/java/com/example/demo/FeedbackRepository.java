package com.example.demo;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.*;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer>{

}