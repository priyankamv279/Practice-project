use db7;
CREATE TABLE `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comments` varchar(255) DEFAULT NULL,
  `rating` int NOT NULL,
  `user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ;

insert into feedback (comments, rating, user) VALUES ("good", 10, "Ray"),("bad", 1, "Jay");
select * from feedback;
truncate table feedback;
drop table feedback;