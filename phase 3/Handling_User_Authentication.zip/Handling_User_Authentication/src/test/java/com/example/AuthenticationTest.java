package com.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AuthenticationTest {

	private Authentication authentication;

	@BeforeEach
	public void setUp() {
		authentication = new Authentication();
	}

	@Test
	public void testValidLogin() {
		boolean result = authentication.login("admin", "admin123");
		assertTrue(result);
	}

	@Test
	public void testInvalidLogin() {
		boolean result = authentication.login("invalidUser", "wrongPassword");
		assertFalse(result);
	}

	@Test
	public void testLogout() {
		boolean result = authentication.logout("admin");
		assertTrue(result);
	}

	@Test
	public void testLogoutWithEmptyUsername() {
		boolean result = authentication.logout("");
		assertFalse(result);
	}

	@Test
	public void testIsValidCredentialsWithValidCredentials() {
		boolean result = authentication.isValidCredentials("admin", "admin123");
		assertTrue(result);
	}

	@Test
	public void testIsValidCredentialsWithInvalidCredentials() {
		boolean result = authentication.isValidCredentials("invalidUser", "wrongPassword");
		assertFalse(result);
	}
}