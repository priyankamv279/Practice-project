package com.example;

public class Authentication {

    public boolean login(String username, String password) {
        // Simulating a basic authentication process 
        return isValidCredentials(username, password);
    }

    public boolean logout(String username) {
        // Simulating a logout process 
        return clearSession(username);
    }


    public boolean isValidCredentials(String username, String password) {
        // Simulating valid credentials
        return username.equals("admin") && password.equals("admin123");
    }

    private boolean clearSession(String username) {
        // Simulating session clearance 
        return username != null && !username.isEmpty();
    }
}