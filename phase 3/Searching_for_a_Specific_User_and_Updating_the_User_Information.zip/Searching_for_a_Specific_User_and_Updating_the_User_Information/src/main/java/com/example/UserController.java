package com.example;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

	@RequestMapping("/getall")
	public ModelAndView getall(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User student=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		List<User> list=dao.getal();
		mv.setViewName("displayall.jsp");
		mv.addObject("list",list);

		return mv;
	}

	@RequestMapping("/getUserByIdForm")
	public ModelAndView getUserByIdForm(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);

		mv.setViewName("userDetails.jsp");

		return mv;
	}

	@RequestMapping("/getUserById")
	public ModelAndView getUserById(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		int userId = Integer.parseInt(request.getParameter("id")); // Get the user ID from the request

		UserDAO dao=ac.getBean(UserDAO.class);
		User user = dao.getUserById(userId);

		if (user != null) {
			mv.setViewName("displayUser.jsp");
			mv.addObject("user", user); // Pass the user object to the JSP view
		} else {
			mv.setViewName("error.jsp");
			mv.addObject("message", "User not found!"); 
		}
		return mv;
	}

	@RequestMapping("/updateUserForm")
	public ModelAndView updateUserForm(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		int userId = Integer.parseInt(request.getParameter("id")); // Get the user ID from the request

		mv.addObject("id", userId); 
		mv.setViewName("updateUser.jsp");

		return mv;
	}

	@RequestMapping("/updateUser")
	public ModelAndView updateUser(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView mv=new ModelAndView();
		ApplicationContext ac=new ClassPathXmlApplicationContext("spring.xml");
		User s=ac.getBean(User.class);
		UserDAO dao=ac.getBean(UserDAO.class);
		int userId = Integer.parseInt(request.getParameter("id")); // Get the user ID from the request
		String name = request.getParameter("name"); 
		String email = request.getParameter("email"); 
		
		User existingUser = dao.getUserById(userId);
		if (existingUser != null) {
			existingUser.setSname(name);
			existingUser.setSemail(email);
			dao.updateUser(existingUser);
			mv.setViewName("successUpdate.jsp");
		} else {
			mv.setViewName("error.jsp");
			mv.addObject("message", "User not found!");
		}
		return mv;
	}
}

