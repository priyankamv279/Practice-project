package com.example;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

public class UserDAO {

	private HibernateTemplate temp;

	public void setTemp(HibernateTemplate temp) {
		this.temp = temp;
	}
	
	//retrieve 
	public List<User> getal(){
		return (List<User>) temp.find("from User");
	}

	// Retrieve user by ID
	public User getUserById(int id) {
		return temp.get(User.class, id);
	}
	
	//update
	 public void updateUser(User user) {
	        temp.update(user);
	    }
}
