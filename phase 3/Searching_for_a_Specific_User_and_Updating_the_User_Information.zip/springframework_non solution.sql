create database db6;
use db6;
drop table user;
create table user(id int primary key,sname varchar(20),semail varchar(20));
insert into user(sname,semail) values ('Priyanka', 'user@email.com'),('Ray', 'user1@email.com');
select * from user;
truncate table user;