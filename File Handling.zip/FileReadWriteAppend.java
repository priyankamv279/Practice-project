package practiceproject;

import java.io.*;
import java.util.Scanner;


public class FileReadWriteAppend {
	public static void main(String[] args) {
		// Define the file name and content
		String fileName = "C:\\Users\\mvpri\\gitrepo\\readme.md";

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the file content");
		String fileContent = sc.nextLine();
		
		// Write to the file
		writeToFile(fileName, fileContent);
		System.out.println("\nContent has been written to the file: \n" +fileContent);

		// Read and display the file content
		String readContent = readFromFile(fileName);
		System.out.println("\nContent read from the file:\n" + readContent);

		// Append additional content to the file
		System.out.println("\nEnter the Append additional content to the file");
		String appendedContent = sc.nextLine();
		appendToFile(fileName, appendedContent);
		System.out.println("\nContent has been appended to the file:\n" +appendedContent);

		// Read and display the updated file content
		String updatedContent = readFromFile(fileName);
		System.out.println("\nUpdated content read from the file:\n" + updatedContent);
	}

	// Method to write content to a file
	public static void writeToFile(String fileName, String content) {
		try (FileWriter writer = new FileWriter(fileName)) {
			writer.write(content);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Method to read content from a file
	public static String readFromFile(String fileName) {
		StringBuilder content = new StringBuilder();
		try (FileReader reader = new FileReader(fileName)) {
			int character;
			while ((character = reader.read()) != -1) {
				content.append((char) character);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return content.toString();
	}

	// Method to append content to a file
	public static void appendToFile(String fileName, String content) {
		try (FileWriter writer = new FileWriter(fileName, true)) {
			writer.write(content);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
