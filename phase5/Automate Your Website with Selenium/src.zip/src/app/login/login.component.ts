import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login(): void {
    // authentication logic
    const isValid = this.authenticate(); 

    if (isValid) {
      alert('Successfully Logged in'); 
      this.router.navigate(['/dashboard']); //on successful login
    } else {
      alert('Invalid credentials. Please try again.'); // Show error message for invalid credentials
    }
  }

  authenticate(): boolean {
    return this.username === 'employee' && this.password === 'admin1';
  }
}
