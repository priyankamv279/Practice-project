import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm: FormGroup = new FormGroup({}); // Initializing the form

  constructor(
    private formBuilder: FormBuilder,
    private router: Router // Inject the Router
  ) { }
  
  ngOnInit(): void {
    this.registrationForm = this.formBuilder.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      console.log(this.registrationForm.value);
      alert('Successfully Registered'); 
      this.router.navigate(['/login']); // Navigate to the login page after successful registration
    } else {
      alert('Invalid credentials. Please try again.'); // Show error message for invalid credentials
    }
  }
  }

