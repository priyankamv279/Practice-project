import { Component } from '@angular/core';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent {
  email: string = '';
  password: string = '';
  validSignIn: boolean = false;
  showErrorMessage: boolean = false;
  showSuccessMessage: boolean = false;

  onSubmit(form: any): void {
    console.log('Form submitted:', form.value); // Log form values to check if data is captured

    // Check if the entered email and password are valid
    if (this.email === 'user@example.com' && this.password === 'user') {
      this.validSignIn = true;
      this.showSuccessMessage = true;
      this.showErrorMessage = false;
    } else {
      this.validSignIn = false;
      this.showErrorMessage = true;
      this.showSuccessMessage = false;
    }
  }
}
