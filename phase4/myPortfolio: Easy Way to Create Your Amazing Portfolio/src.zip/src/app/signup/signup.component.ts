import { Component } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'] 
})
export class SignupComponent {
  showSuccessMessage: boolean = false;
  showErrorMessage: boolean = false;


  onSubmit(form: any): void {
    console.log('Form submitted:', form.value); // Log form values to check if data is captured

    if (form.valid) {
      // For demonstration, just showing the success message
      this.showSuccessMessage = true;
      setTimeout(() => {
        this.showSuccessMessage = false;
      }, 8000);
      
  }
  else{
    this.showErrorMessage = true;
    setTimeout(() => {
      this.showErrorMessage = false;
      form.resetForm();
    }, 3000);
  }
}
}