// AddProductServlet.java


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ecommerce.Product;
import com.ecommerce.ProductService;

@WebServlet("/AddProductServlet")
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // Retrieve form data
            String productName = request.getParameter("productName");
            double productPrice = Double.parseDouble(request.getParameter("productPrice"));
            String productDescription = request.getParameter("productDescription");

            // Create a Product instance
            Product product = new Product(productName, productPrice, productDescription);

            // Call a method to save product using Hibernate
            ProductService.saveProduct(product);

         // Store the product in the request attribute
            request.setAttribute("product", product);
            
            // Redirect to a success page
            request.getRequestDispatcher("success.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception as needed, perhaps redirect to an error page
            response.sendRedirect("error.jsp");
        }
    }
}
