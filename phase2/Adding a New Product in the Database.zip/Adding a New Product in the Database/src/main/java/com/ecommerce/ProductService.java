package com.ecommerce;


import org.hibernate.Session;
import org.hibernate.Transaction;

public class ProductService {

 public static void saveProduct(Product product) {
     try (Session session = HibernateUtil.getSessionFactory().openSession()) {
         Transaction transaction = session.beginTransaction();
         session.save(product);
         transaction.commit();
     } catch (Exception e) {
         e.printStackTrace();
     }
 }
}
