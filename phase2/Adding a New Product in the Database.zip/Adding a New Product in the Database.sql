create database db5;
use db5;
select * from Product;


