CREATE DATABASE ecommerce ;
USE ecommerce;
CREATE TABLE product (
    ProductID bigint primary key auto_increment,
    name varchar(100),
    price decimal(10, 2),
    date_added timestamp default now()
);

INSERT INTO product (name, price) VALUES ('HP Laptop ABC', 12000.00);
INSERT INTO product (name, price) VALUES ('Acer Laptop ABC', 14000.00);
INSERT INTO product (name, price) VALUES ('Lenovo Laptop ABC', 12000.00);

SELECT * from product;